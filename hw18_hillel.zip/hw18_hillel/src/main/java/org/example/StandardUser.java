package org.example;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;



public class StandardUser {
    By inputuserName = By.xpath("//div[@class = 'form_group']//input[@id='user-name']");
    By inputpassword = By.xpath("//div[@class = 'form_group']//input[@id='password']");
    By btnlogin = By.xpath("//div[@class = 'login-box']//input[@id='login-button']");

    @Test
    public void testforstandarduser () {
        WebDriver driver = new ChromeDriver();
        Data getDate = new Data();
        driver.get(getDate.getUrl);
        driver.findElement(inputuserName).sendKeys(getDate.userName);
        driver.findElement(inputpassword).sendKeys(getDate.password);
        driver.findElement(btnlogin).click();
        driver.findElement(By.className("inventory_item_name")).click();
        String expected_result = "carry.allTheThings() with the sleek, streamlined Sly Pack that melds uncompromising style with unequaled laptop and tablet protection.";
        String actual_result = driver.findElement(By.xpath("//div[2]/div/div/div[2]/div[2]")).getText();
        Assert.assertEquals(expected_result,actual_result);



    }
}

