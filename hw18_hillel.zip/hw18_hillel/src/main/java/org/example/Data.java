package org.example;

public class Data {
    public String getUrl = "https://www.saucedemo.com/";
    public String userName = "standard_user";
    public String password = "secret_sauce";

}
